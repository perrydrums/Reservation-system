<?php include("php/adminStart.php"); ?>

<!DOCTYPE>
<html>
<head>
    <title>Reserveringssysteem</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="shortcut icon" href="favicon.ico">
    <meta charset="utf-8">

    <!-- Font -->
    <link href="//fonts.googleapis.com/css?family=Andada" rel="stylesheet">

    <!-- Jquery -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>

<div id="wrapper">

    <h1>Admin</h1><br/>


    <h2>Priv&eacute;lessen data</h2><hr>
    <form action="" method="POST" name="privateFormSetDates">
        <table cellspacing="0" cellpadding="0" width="100%" id="adminDataTable">
            <?php include("php/dataForm.php"); ?>
        </table>
        <table width="100%" style="margin-top: 10px">
            <tr><td colspan="4"><input type="submit" name="submit" value="Opslaan" class="submitButton"></td></tr>
        </table>
    </form>

<!--   Turn groupdays on or off   -->
    <h2 style="margin-top: 60px">Zet groepslesdagen aan/uit</h2><hr>
    <form action="" method="POST">
        <table cellspacing="0" cellpadding="0" width="100%" style="margin-top: 25px" id="adminDataTable">
            <tr>
                <td style="width: 30%">Maandag</td>
                <td style="width: 30%"><input value="1" type="checkbox" name="monday1" <?php if($days['monday1']){ echo 'checked'; } ?>>15:45</td>
                <td><input type="checkbox" value="1" name="monday2" <?php if($days['monday2']){ echo 'checked'; } ?>>16:45</td>
            </tr>
            <tr>
                <td style="width: 30%">Woensdag</td>
                <td style="width: 30%"><input value="1" type="checkbox" name="wednesday" <?php if($days['wednesday']){ echo 'checked'; } ?>>13:45</td>
                <td></td>
            </tr>
            <tr>
                <td style="width: 30%">Donderdag</td>
                <td style="width: 30%"><input value="1" type="checkbox" name="thursday" <?php if($days['thursday']){ echo 'checked'; } ?>>16:30</td>
                <td></td>
            </tr>
            <tr>
                <td style="width: 30%">Vrijdag</td>
                <td style="width: 30%"><input value="1" type="checkbox" name="friday" <?php if($days['friday']){ echo 'checked'; } ?>>19:30</td>
                <td></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
        </table>
        <input class="submitButton" type="submit" name="submit2" value="Opslaan">
    </form>

    <br><h1>Geplande proeflessen</h1><br>
    <?php include("php/plannedLessons.php") ?>

</div>

</body>
</html>