<?php
include("php/connect.php");

if (isset ($_GET["datum"])) {
    $datum = $_GET["datum"];
    $query1 = mysqli_query($connect,"SELECT * FROM available WHERE date='$datum'");
    $rows = array();
    while($r = mysqli_fetch_assoc($query1)) {
        $rows[] = $r;
    }
    print json_encode($rows);
}

?>