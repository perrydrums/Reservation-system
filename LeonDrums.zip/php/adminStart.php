<?php
include("connect.php");
require ("vendor/vendor/phpmailer/phpmailer/PHPMailerAutoload.php");

//Admin login system
session_start();

//Log out if away for more than 900s (15 minutes)
if (isset($_SESSION['time']) && (time() - $_SESSION['time'] > 900)) {
    session_unset();
    session_destroy();
}

$_SESSION['time'] = time();

//If not logged in: show login form
if(!isset($_SESSION['id'])){
    if(isset($_POST['login'])){
        if($_POST['password'] == $adminPass){
            $_SESSION['id'] = true;
            header("Location: admin.php");
        }else{
            echo '<center>Wachtwoord fout!</center>';
        }
    }
?>
    <span style="text-align: center">
        <h1 style="margin-top: 5%">LeonDrums - Admin</h1>
        <form action="" method="POST">
            <input type="password" required name="password" placeholder="Wachtwoord">
            <input type="submit" name="login" value="Log in">
        </form>
    </span>
<?php die; } else {


    //Process dataForm input
    if (isset($_POST['submit'])) {

        for ($selectNumber = 0; $selectNumber < (count($_POST) / 2) - 1; $selectNumber++) { //Loop for as many inputs are sent
            $time = $_POST['select' . $selectNumber];                                     //Its the number of entries in the _POST array
            $date = date("Y-m-d", $_POST['hidden' . $selectNumber]);                       //divided by 2 (because of hidden entries) and -1 (submit button)

            //Is time not empty? Insert date and time in database
            if ($_POST['select' . $selectNumber] != '') {
                $insertDate = mysqli_query($connect, "INSERT INTO available VALUES ('','$date','$time')");
            }
        }
        header("Location: admin.php");
    }

    //Select available grouplesson days
    $groupDays = mysqli_query($connect, "SELECT * FROM groupdays");
    $days = mysqli_fetch_array($groupDays);

    //Delete and insert into table groupdays
    if (isset($_POST['submit2'])) {
        $monday1 = $_POST['monday1'];
        $monday2 = $_POST['monday2'];
        $wednesday = $_POST['wednesday'];
        $thursday = $_POST['thursday'];
        $friday = $_POST['friday'];

        mysqli_query($connect, "DELETE FROM groupdays");
        mysqli_query($connect, "INSERT INTO groupdays VALUES ('','" . $monday1 . "','" . $monday2 . "','" . $wednesday . "','" . $thursday . "','" . $friday . "')");
        header("Location: admin.php");
    }
}
?>