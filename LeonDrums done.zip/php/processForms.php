<?php

include("connect.php");


//Process Group Form
if(isset($_POST['submitGroupForm'])){

    $firstName = addslashes($_POST['firstName']);
    $lastName = addslashes($_POST['lastName']);
    $email = addslashes($_POST['email']);
    $tel = addslashes($_POST['tel']);
    $age = addslashes($_POST['age']);
    $gender = addslashes($_POST['gender']);
    $dateTime = addslashes($_POST['dateTime']);

    $insertGroupLesson = mysqli_query($connect,"INSERT INTO grouplessons VALUES ('','$firstName','$lastName','$email','$tel','$age','$gender','$dateTime')");

    //This will show if the user had Javascript disabled (or something went wrong)
    echo("<div id='alert'>Afspraak gemaakt!</div>");

    include("sendMail.php");


//Process Private Form
}elseif(isset($_POST['submitPrivateForm'])){

    $firstName = addslashes($_POST['firstName']);
    $lastName = addslashes($_POST['lastName']);
    $email = addslashes($_POST['email']);
    $tel = addslashes($_POST['tel']);
    $age = addslashes($_POST['age']);
    $gender = addslashes($_POST['gender']);

    //Merge date and time variables into mySQL DateTime
    $date = $_POST['date'];
    $time = $_POST['time'];
    $dateTime = date("Y-m-d H:i:s",strtotime($date.' '.$time));

    $insertPrivateLesson = mysqli_query($connect,"INSERT INTO privatelessons VALUES ('','$firstName','$lastName','$email','$tel','$age','$gender','$dateTime')");
    //Remove date from availability
    $removeFromAvailable = mysqli_query($connect,"DELETE FROM available WHERE date = '".$date."' AND time = '".$time."'");

    //This will show if the user had Javascript disabled (or something went wrong)
    echo("<div id='alert'>Afspraak gemaakt!</div>");

    include("sendMail.php");



}else{}