<?php

include("connect.php");


//Process Group Form
if(isset($_POST['submitGroupForm'])){

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $dateTime = $_POST['dateTime'];

    $insertGroupLesson = mysqli_query($connect,"INSERT INTO grouplessons VALUES ('','$firstName','$lastName','$email','$tel','$age','$gender','$dateTime')");

    //This will show if the user had Javascript disabled (or something went wrong)
    echo("<div id='alert'>Afspraak gemaakt!</div>");

    include("sendMail.php");


//Process Private Form
}elseif(isset($_POST['submitPrivateForm'])){

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];

    //Merge date and time variables into mySQL DateTime
    $date = $_POST['date'];
    $time = $_POST['time'];
    $dateTime = date("Y-m-d H:i:s",strtotime($date.' '.$time));

    $insertPrivateLesson = mysqli_query($connect,"INSERT INTO privatelessons VALUES ('','$firstName','$lastName','$email','$tel','$age','$gender','$dateTime')");
    //Remove date from availability
    $removeFromAvailable = mysqli_query($connect,"DELETE FROM available WHERE date = '".$date."' AND time = '".$time."'");


    include("sendMail.php");



}else{}