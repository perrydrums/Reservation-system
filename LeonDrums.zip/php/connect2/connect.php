<?php

$connect = mysqli_connect("stud.hosted.hr.nl","0924208","edaigiep","leondrums");//host, username, password, database

if(!$connect){
    echo "Kan niet verbinden met database.";
}else{
    //echo "Verbonden met database.";
}

//Mail info
$mailUsername   = 'psperryjanssen@gmail.com';
$mailPassword   = 'psnidassdei1';

//Sender of mail
$mailFrom       = 'psperryjanssen@gmail.com';
$mailFromName   = 'Drumschool Leon van der Geest';

//Receiver of mail (this one's for yourself) (mail gets also sent to user)
$mailSendTo     = 'psperryjanssen@gmail.com';
$mailSendToName = 'Perry Janssen';

//Email which users can contact
$replyToMail    = '<psperryjanssen@gmail.com>';
