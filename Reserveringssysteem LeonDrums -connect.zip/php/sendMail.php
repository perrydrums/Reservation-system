<?php
require("../vendor/vendor/phpmailer/phpmailer/PHPMailerAutoload.php");
include("../snippets/mailTemplate.php");

$m = new PHPMailer;

$m->isSMTP();
$m->SMTPAuth = true;
//$m->SMTPDebug = 2;

$m->Host = 'smtp.gmail.com';
$m->Port = 465;
$m->Username = $mailUsername;
$m->Password = $mailPassword;
$m->SMTPSecure = 'ssl';

$m->From = $mailFrom;
$m->FromName = $mailFromName;
$m->addAddress('psperryjanssen@gmail.com', 'Perry Janssen');
$m->addAddress($email, $firstName.' '.$lastName);
$m->addCustomHeader( 'In-Reply-To', $replyToMail);

$m->Subject = 'Les gepland!';
$m->Body = $emailMessage;
$m->AltBody = 'INFO plain text';

$m->send();